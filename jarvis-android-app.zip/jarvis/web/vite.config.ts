import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  // The key is only injected in dev. Production bundles never contain it.
  const devKey = mode === 'development' ? env.GEMINI_API_KEY ?? '' : '';
  return {
    base: './',
    define: { 'process.env.GEMINI_API_KEY': JSON.stringify(devKey) },
    build: {
      outDir: '../android/app/src/main/assets/dist',
      emptyOutDir: true,
      assetsDir: 'assets',
      target: 'es2022',
      chunkSizeWarningLimit: 1800,
    },
  };
});
