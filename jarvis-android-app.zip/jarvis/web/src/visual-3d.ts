import { LitElement, css, html } from 'lit';
import * as THREE from 'three';
import { EXRLoader } from 'three/examples/jsm/loaders/EXRLoader.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { Analyser } from './analyser';
import { fs as backdropFS, vs as backdropVS } from './backdrop-shader';
import { ORB } from './config';
import { applySphereShader } from './sphere-shader';

export type OrbMode = 'idle' | 'connecting' | 'listening' | 'speaking' | 'working' | 'muted';

// Optional: drop piz_compressed.exr into src/assets to use it as the reflection map.
const exrFiles = import.meta.glob('./assets/*.exr', { query: '?url', import: 'default', eager: true }) as Record<string, string>;

const ZERO = new Uint8Array(16);
const STYLE: Record<OrbMode, { glow: number; breath: number; speed: number }> = {
  idle: { glow: 1.1, breath: 0.012, speed: 0.8 },
  connecting: { glow: 1.3, breath: 0.03, speed: 2.2 },
  listening: { glow: 1.5, breath: 0.01, speed: 1.0 },
  speaking: { glow: 1.8, breath: 0.0, speed: 1.0 },
  working: { glow: 1.5, breath: 0.05, speed: 1.6 },
  muted: { glow: 0.6, breath: 0.006, speed: 0.6 },
};

function studioScene(accent: THREE.Color): THREE.Scene {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x020308);
  const hsl = { h: 0, s: 0, l: 0 };
  accent.getHSL(hsl);
  const panel = (c: THREE.Color, w: number, h: number, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide }));
    m.position.set(x, y, z); m.lookAt(0, 0, 0); scene.add(m);
  };
  const hue = (dh: number, l: number, k: number) => new THREE.Color().setHSL((hsl.h + dh + 1) % 1, 0.9, l).multiplyScalar(k);
  panel(hue(0, 0.55, 2.2), 14, 3, -9, 3, 4);
  panel(hue(0.12, 0.6, 1.8), 10, 2.5, 8, -2, 6);
  panel(hue(0.55, 0.55, 1.5), 12, 3, 3, 7, -8);
  panel(new THREE.Color(0xdfeaff).multiplyScalar(2.5), 6, 6, 0, 10, 1);
  panel(new THREE.Color(0xffb36b).multiplyScalar(1.2), 8, 2, -6, -6, -7);
  return scene;
}

export class JarvisOrb extends LitElement {
  static properties = {
    inputNode: { attribute: false },
    outputNode: { attribute: false },
    mode: { type: String },
    accent: { type: String },
  };
  declare inputNode: AudioNode | null;
  declare outputNode: AudioNode | null;
  declare mode: OrbMode;
  declare accent: string;

  static styles = css`
    :host { display: block; position: absolute; inset: 0; }
    canvas { width: 100%; height: 100%; display: block; }
  `;

  private inputAnalyser: Analyser | null = null;
  private outputAnalyser: Analyser | null = null;
  private renderer!: THREE.WebGLRenderer;
  private composer!: EffectComposer;
  private camera!: THREE.PerspectiveCamera;
  private sphere!: THREE.Mesh;
  private backdrop!: THREE.Mesh;
  private pmrem!: THREE.PMREMGenerator;
  private envTarget: THREE.WebGLRenderTarget | null = null;
  private usingExr = false;
  private shader: { uniforms: Record<string, { value: any }> } | null = null;
  private raf = 0;
  private ro: ResizeObserver | null = null;
  private pixelRatio = 1;
  private prevTime = 0;
  private fpsFrames = 0;
  private fpsStart = 0;
  private time = 0;
  private glow = 1.5;
  private readonly rotation = new THREE.Vector3();
  private readonly euler = new THREE.Euler();
  private readonly quat = new THREE.Quaternion();
  private readonly vec = new THREE.Vector3();
  private readonly accentColor = new THREE.Color();
  private inited = false;

  constructor() {
    super();
    this.inputNode = null; this.outputNode = null; this.mode = 'idle'; this.accent = '#4d7cff';
  }

  protected render() { return html`<canvas></canvas>`; }

  protected updated(changed: Map<string, unknown>) {
    if (changed.has('inputNode')) {
      this.inputAnalyser?.dispose();
      this.inputAnalyser = this.inputNode ? new Analyser(this.inputNode) : null;
    }
    if (changed.has('outputNode')) {
      this.outputAnalyser?.dispose();
      this.outputAnalyser = this.outputNode ? new Analyser(this.outputNode) : null;
    }
    if (changed.has('accent') && this.inited) this.applyAccent();
  }

  protected firstUpdated() { this.init(); }
  connectedCallback() { super.connectedCallback(); if (this.inited && !this.raf) this.start(); }
  disconnectedCallback() {
    super.disconnectedCallback();
    cancelAnimationFrame(this.raf); this.raf = 0; this.ro?.disconnect();
  }

  private size() { return { w: this.clientWidth || window.innerWidth, h: this.clientHeight || window.innerHeight }; }

  private init() {
    const canvas = this.renderRoot.querySelector('canvas') as HTMLCanvasElement;
    const { w, h } = this.size();
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
    this.pixelRatio = Math.min(window.devicePixelRatio || 1, ORB.maxPixelRatio);
    renderer.setPixelRatio(this.pixelRatio);
    renderer.setSize(w, h, false);
    this.renderer = renderer;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x100c14);

    this.backdrop = new THREE.Mesh(
      new THREE.IcosahedronGeometry(10, 5),
      new THREE.RawShaderMaterial({
        uniforms: { resolution: { value: new THREE.Vector2(1, 1) }, rand: { value: 0 }, tint: { value: new THREE.Vector3() } },
        vertexShader: backdropVS, fragmentShader: backdropFS, glslVersion: THREE.GLSL3, side: THREE.BackSide,
      }),
    );
    scene.add(this.backdrop);

    this.camera = new THREE.PerspectiveCamera(75, w / h, 0.1, 1000);
    this.camera.position.set(2, -2, 5);

    const material = new THREE.MeshStandardMaterial({
      color: 0x000010, metalness: 0.5, roughness: 0.1, emissive: 0x000010, emissiveIntensity: 1.5,
    });
    material.onBeforeCompile = (shader) => {
      applySphereShader(shader as any);
      this.shader = shader as any;
    };
    this.sphere = new THREE.Mesh(new THREE.IcosahedronGeometry(1, ORB.detail), material);
    scene.add(this.sphere);

    this.pmrem = new THREE.PMREMGenerator(renderer);
    this.applyAccent();
    const exr = Object.values(exrFiles)[0];
    if (exr) {
      this.pmrem.compileEquirectangularShader();
      new EXRLoader().load(exr, (tex) => {
        tex.mapping = THREE.EquirectangularReflectionMapping;
        const rt = this.pmrem.fromEquirectangular(tex);
        this.envTarget?.dispose(); this.envTarget = rt; this.usingExr = true;
        material.envMap = rt.texture; material.needsUpdate = true; tex.dispose();
      });
    }

    this.composer = new EffectComposer(renderer);
    this.composer.addPass(new RenderPass(scene, this.camera));
    this.composer.addPass(new UnrealBloomPass(new THREE.Vector2(w, h), ORB.bloomStrength, ORB.bloomRadius, ORB.bloomThreshold));

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(this);
    this.resize();
    this.inited = true;
    this.start();
  }

  private applyAccent() {
    try { this.accentColor.set(this.accent); } catch { /* keep previous */ }
    const mat = this.sphere.material as THREE.MeshStandardMaterial;
    mat.emissive.copy(this.accentColor).multiplyScalar(0.012);
    (this.backdrop.material as THREE.RawShaderMaterial).uniforms.tint.value.set(this.accentColor.r, this.accentColor.g, this.accentColor.b);
    if (!this.usingExr) {
      const rt = this.pmrem.fromScene(studioScene(this.accentColor), 0.02);
      this.envTarget?.dispose(); this.envTarget = rt;
      mat.envMap = rt.texture; mat.needsUpdate = true;
    }
  }

  private resize() {
    const { w, h } = this.size();
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.setSize(w, h, false);
    this.composer.setPixelRatio(this.pixelRatio);
    this.composer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.setViewOffset(w, h, 0, h > w ? Math.round(h * 0.07) : 0, w, h); // lift the orb above the controls
    this.camera.updateProjectionMatrix();
    (this.backdrop.material as THREE.RawShaderMaterial).uniforms.resolution.value.set(w * this.pixelRatio, h * this.pixelRatio);
  }

  private start() { this.prevTime = 0; this.raf = requestAnimationFrame(this.tick); }
  private tick = (now: number) => {
    this.raf = requestAnimationFrame(this.tick);
    this.frame(now);
  };

  private frame(now: number) {
    const dtMs = this.prevTime ? now - this.prevTime : 16.7;
    this.prevTime = now;
    const dt = Math.min(dtMs, 100) / (1000 / 60);
    this.adaptQuality(now, dtMs);

    this.inputAnalyser?.update(); this.outputAnalyser?.update();
    const i = this.inputAnalyser?.data ?? ZERO, o = this.outputAnalyser?.data ?? ZERO;
    const st = STYLE[this.mode] ?? STYLE.idle;
    const breath = Math.sin(now * 0.001 * st.speed * Math.PI * 2 * 0.5) * st.breath;

    this.sphere.scale.setScalar(1 + (0.2 * o[1]) / 255 + breath);
    const f = 0.001;
    this.rotation.x += (dt * f * 0.5 * o[1]) / 255;
    this.rotation.z += (dt * f * 0.5 * i[1]) / 255;
    this.rotation.y += (dt * f * 0.25 * i[2]) / 255 + (dt * f * 0.25 * o[2]) / 255 + dt * 0.0003;

    const aspect = this.camera.aspect;
    this.vec.set(0, 0, 5 + Math.max(0, 0.55 - aspect) * 4).applyQuaternion(this.quat.setFromEuler(this.euler.set(this.rotation.x, this.rotation.y, this.rotation.z)));
    this.camera.position.copy(this.vec);
    this.camera.lookAt(this.sphere.position);

    (this.backdrop.material as THREE.RawShaderMaterial).uniforms.rand.value = Math.random() * 10000;
    this.glow += (st.glow - this.glow) * 0.08;
    (this.sphere.material as THREE.MeshStandardMaterial).emissiveIntensity = this.glow;

    const sh = this.shader;
    if (sh) {
      this.time += (dt * 0.1 * o[0]) / 255;
      sh.uniforms.time.value = this.time;
      sh.uniforms.inputData.value.set((1 * i[0]) / 255, (0.1 * i[1]) / 255, (10 * i[2]) / 255, 0);
      sh.uniforms.outputData.value.set((2 * o[0]) / 255, (0.1 * o[1]) / 255, (10 * o[2]) / 255, 0);
    }
    this.composer.render();
  }

  /** Lower the render resolution if the phone cannot hold ~45 fps. */
  private adaptQuality(now: number, dtMs: number) {
    if (document.hidden || dtMs > 250) { this.fpsFrames = 0; this.fpsStart = now; return; }
    if (!this.fpsStart) this.fpsStart = now;
    if (++this.fpsFrames < 90) return;
    const fps = (this.fpsFrames * 1000) / (now - this.fpsStart);
    this.fpsFrames = 0; this.fpsStart = now;
    if (fps < 45 && this.pixelRatio > 1) { this.pixelRatio = Math.max(1, this.pixelRatio - 0.25); this.resize(); }
  }
}
customElements.define('jarvis-orb', JarvisOrb);
