import '@fontsource/sora/300.css';
import '@fontsource/sora/400.css';
import '@fontsource/sora/600.css';
import { LitElement, css, html, nothing } from 'lit';
import { extractMemories } from './learn';
import { LiveSession, type SessionStatus, type StopReason, type Turn } from './live-session';
import { ConversationLog, MemoryStore } from './memory';
import { native } from './native';
import { buildGreeting, buildSystemInstruction } from './persona';
import { loadSettings, resolveApiKey, saveApiKey, saveSettings, type Settings } from './settings';
import { executeTool } from './tools';
import { modelProfile } from './config';
import { iconHeart, iconList, iconMic, iconMicOff, iconSliders, iconStop } from './icons';
import { baseStyles } from './ui-styles';
import './visual-3d';
import './ui-memory';
import './ui-settings';
import './ui-log';

type Sheet = 'memory' | 'settings' | 'log' | null;
const LABEL: Record<SessionStatus, string> = {
  idle: 'Tap the mic to talk', connecting: 'Connecting', listening: 'Listening', speaking: 'Speaking',
  working: 'On it', reconnecting: 'Reconnecting', error: 'Something went wrong',
};

export class JarvisApp extends LitElement {
  static properties = {
    status: { state: true }, muted: { state: true }, userLine: { state: true }, modelLine: { state: true },
    toastText: { state: true }, sheet: { state: true }, settings: { state: true },
  };
  declare status: SessionStatus; declare muted: boolean; declare userLine: string; declare modelLine: string;
  declare toastText: string; declare sheet: Sheet; declare settings: Settings;

  static styles = [baseStyles, css`
    :host { display: block; position: absolute; inset: 0; overflow: hidden; }
    .top { position: absolute; top: 0; left: 0; right: 0; display: flex; align-items: flex-start; justify-content: space-between;
      padding: calc(14px + env(safe-area-inset-top, 0px)) 12px 0 22px; z-index: 2; }
    .brand { font-size: 20px; font-weight: 300; letter-spacing: .04em; }
    .state { margin-top: 2px; font-size: 12px; color: var(--haze); min-height: 16px; }
    .state.error { color: var(--danger); }
    .icons { display: flex; gap: 2px; color: var(--haze); }
    .caps { position: absolute; left: 0; right: 0; bottom: calc(150px + env(safe-area-inset-bottom, 0px)); padding: 0 28px;
      text-align: center; display: flex; flex-direction: column; gap: 8px; pointer-events: none; z-index: 2; }
    .you { color: var(--haze); font-size: 14px; font-weight: 300; max-height: 3.1em; overflow: hidden; }
    .jarvis { font-size: 18px; font-weight: 300; line-height: 1.45; max-height: 6.2em; overflow: hidden; text-shadow: 0 1px 14px rgba(0,0,0,.7); }
    .dock { position: absolute; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; gap: 34px;
      padding: 0 20px calc(30px + env(safe-area-inset-bottom, 0px)); z-index: 2; }
    .side { width: 52px; height: 52px; border-radius: 50%; display: grid; place-items: center; background: var(--glass);
      border: 1px solid var(--line); color: var(--ink); }
    .side[aria-pressed=true] { color: var(--danger); border-color: var(--danger); }
    .side:disabled { opacity: .35; }
    .main { width: 78px; height: 78px; border-radius: 50%; display: grid; place-items: center; position: relative;
      background: var(--accent); color: #04060f; box-shadow: 0 0 38px color-mix(in srgb, var(--accent) 55%, transparent); }
    .main.live { background: var(--glass-strong); color: var(--ink); border: 1.5px solid var(--accent); }
    .main.live::after { content: ''; position: absolute; inset: -8px; border-radius: 50%; border: 1px solid var(--accent); opacity: .5; animation: ring 2.4s ease-out infinite; }
    @keyframes ring { from { transform: scale(.92); opacity: .55; } to { transform: scale(1.22); opacity: 0; } }
    .toast { position: absolute; left: 50%; top: calc(76px + env(safe-area-inset-top, 0px)); transform: translate(-50%, -8px); max-width: 86%;
      padding: 10px 16px; border-radius: 14px; background: var(--glass-strong); border: 1px solid var(--line); font-size: 13px;
      opacity: 0; pointer-events: none; transition: opacity .2s, transform .2s; z-index: 3; text-align: center; }
    .toast.show { opacity: 1; transform: translate(-50%, 0); }
    @media (prefers-reduced-motion: reduce) { .main.live::after { animation: none; } .toast { transition: none; } }
  `];

  readonly memory = new MemoryStore();
  readonly log = new ConversationLog();
  private live!: LiveSession;
  private toastTimer = 0;
  private sessionStart = 0;
  private wake: { release(): Promise<void> } | null = null;

  constructor() {
    super();
    this.status = 'idle'; this.muted = false; this.userLine = ''; this.modelLine = ''; this.toastText = '';
    this.sheet = null; this.settings = loadSettings();
  }

  connectedCallback() {
    super.connectedCallback();
    this.applyAccent();
    this.live = new LiveSession({
      getApiKey: resolveApiKey,
      getSettings: () => this.settings,
      nativeAvailable: native.available,
      buildPrompt: () => ({
        systemInstruction: buildSystemInstruction({
          settings: this.settings, memories: this.memory.list(), native: native.available,
          recap: this.settings.recallRecent ? this.log.recap() : '',
        }),
        greeting: this.settings.greet ? buildGreeting(this.settings, this.memory.count) : null,
      }),
      runTool: (call, modelId) => executeTool(call, {
        memory: this.memory,
        setAccent: (c) => this.setAccent(c),
        saved: (text, st) => this.toast(st === 'duplicate' ? 'Already remembered' : `Remembered: ${text}`),
      }, modelProfile(modelId)),
      onStatus: (s) => { this.status = s; if (s === 'idle') this.muted = false; },
      onCaption: (role, text) => { if (role === 'user') this.userLine = text; else this.modelLine = text; },
      onTurn: (t) => this.log.append(t.role, t.text, t.ts),
      onError: (m) => this.toast(m, 6000),
      onEnded: (turns, reason) => { this.keepAwake(false); void this.learn(turns, reason); },
    });
    document.addEventListener('visibilitychange', this.onVisibility);
    window.__jarvisBack = () => { if (!this.sheet) return false; this.openSheet(null); return true; };
    this.requestUpdate();
  }
  disconnectedCallback() { super.disconnectedCallback(); document.removeEventListener('visibilitychange', this.onVisibility); this.live?.stop('background'); }

  private onVisibility = () => { if (document.hidden && this.live?.isActive) this.live.stop('background'); };

  /* ---------- helpers ---------- */
  private toast(text: string, ms = 3200) {
    this.toastText = text; clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => (this.toastText = ''), ms);
  }
  private haptic(ms: number) { if (this.settings.haptics) { if (native.available) native.vibrate(ms); else navigator.vibrate?.(ms); } }
  private applyAccent() { this.style.setProperty('--accent', this.settings.accent); document.documentElement.style.setProperty('--accent', this.settings.accent); }
  private setAccent(color: string): boolean {
    if (!CSS.supports('color', color)) return false;
    this.update_({ accent: color }); return true;
  }
  private update_(patch: Partial<Settings>) {
    this.settings = { ...this.settings, ...patch }; saveSettings(this.settings);
    if (patch.accent) this.applyAccent();
  }
  private openSheet(s: Sheet) { this.sheet = s; native.setBackHandled(s !== null); }
  private keyHint(): string {
    const k = resolveApiKey();
    return k ? `Key in use: …${k.slice(-4)}. Paste a new one to replace it.` : '';
  }
  private async keepAwake(on: boolean) {
    native.keepScreenOn(on);
    try {
      if (on) this.wake = (await (navigator as any).wakeLock?.request('screen')) ?? null;
      else { await this.wake?.release(); this.wake = null; }
    } catch { /* not supported */ }
  }

  /* ---------- actions ---------- */
  private async toggle() {
    this.haptic(14);
    if (this.live.isActive) { this.live.stop('user'); return; }
    if (!resolveApiKey()) { this.toast('Add your Gemini API key to get started.'); this.openSheet('settings'); return; }
    this.userLine = ''; this.modelLine = '';
    this.sessionStart = Date.now();
    try { await this.live.start(); this.keepAwake(true); }
    catch (e) {
      const err = e as Error;
      this.keepAwake(false);
      if (err.name === 'NotAllowedError' || err.name === 'SecurityError') this.toast('Microphone access is blocked. Allow it in your phone settings.', 6000);
      else if (err.message !== 'NO_API_KEY') this.toast(`Could not start: ${err.message || err.name}`, 6000);
    }
  }
  private mute() { this.muted = !this.live.isMuted; this.live.setMuted(this.muted); this.haptic(8); }

  private async learn(turns: Turn[], reason: StopReason) {
    const s = this.settings;
    const said = turns.filter((t) => t.role === 'user');
    if (!s.autoLearn || reason === 'error' || said.length < 2 || said.reduce((n, t) => n + t.text.length, 0) < 30) return;
    try {
      const found = await extractMemories({ apiKey: resolveApiKey(), model: s.textModel, turns, existing: this.memory.list() });
      let n = 0;
      for (const f of found) { const r = this.memory.add(f.text, f.category, { importance: f.importance, source: 'auto' }); if (r.status === 'added' || r.status === 'replaced') n++; }
      if (n) this.toast(n === 1 ? 'Remembered 1 new thing about you' : `Remembered ${n} new things about you`);
    } catch (e) { console.warn('[jarvis] learning skipped', e); }
  }

  /* ---------- view ---------- */
  protected render() {
    const live = this.status !== 'idle' && this.status !== 'error';
    const mode = this.muted && live ? 'muted' : this.status === 'idle' || this.status === 'error' ? 'idle'
      : this.status === 'reconnecting' ? 'connecting' : this.status;
    const label = this.muted && live ? 'Mic muted' : LABEL[this.status];
    return html`
      <jarvis-orb .inputNode=${this.live?.inputNode ?? null} .outputNode=${this.live?.outputNode ?? null}
        .mode=${mode} .accent=${this.settings.accent}></jarvis-orb>
      <div class="top">
        <div><div class="brand">Jarvis</div><div class="state ${this.status === 'error' ? 'error' : ''}" aria-live="polite">${label}</div></div>
        <div class="icons">
          <button class="icon-btn" aria-label="Memory" @click=${() => this.openSheet('memory')}>${iconHeart}</button>
          <button class="icon-btn" aria-label="Settings" @click=${() => this.openSheet('settings')}>${iconSliders}</button>
        </div>
      </div>
      <div class="toast ${this.toastText ? 'show' : ''}" role="status">${this.toastText}</div>
      ${this.settings.captions ? html`<div class="caps" aria-live="polite">
        ${this.userLine ? html`<div class="you">${this.userLine}</div>` : nothing}
        ${this.modelLine ? html`<div class="jarvis">${this.modelLine}</div>` : nothing}</div>` : nothing}
      <div class="dock">
        <button class="side" aria-label=${this.muted ? 'Unmute microphone' : 'Mute microphone'} aria-pressed=${this.muted}
          ?disabled=${!live} @click=${this.mute}>${this.muted ? iconMicOff : iconMic}</button>
        <button class="main ${live ? 'live' : ''}" aria-label=${live ? 'End conversation' : 'Start conversation'}
          @click=${this.toggle}>${live ? iconStop : iconMic}</button>
        <button class="side" aria-label="Conversation history" @click=${() => this.openSheet('log')}>${iconList}</button>
      </div>
      <jarvis-memory-sheet ?open=${this.sheet === 'memory'} .store=${this.memory} @close=${() => this.openSheet(null)}></jarvis-memory-sheet>
      <jarvis-log-sheet ?open=${this.sheet === 'log'} .log=${this.log} @close=${() => this.openSheet(null)}></jarvis-log-sheet>
      <jarvis-settings-sheet ?open=${this.sheet === 'settings'} .settings=${this.settings} .keyHint=${this.keyHint()}
        @close=${() => this.openSheet(null)}
        @settings-change=${(e: CustomEvent<Partial<Settings>>) => this.update_(e.detail)}
        @save-key=${(e: CustomEvent<string>) => { saveApiKey(e.detail); this.toast('API key saved'); this.requestUpdate(); }}></jarvis-settings-sheet>`;
  }
}
customElements.define('jarvis-app', JarvisApp);
