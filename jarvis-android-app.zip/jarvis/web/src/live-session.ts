import { GoogleGenAI, Modality } from '@google/genai';
import type { LiveConnectConfig, LiveServerMessage, LiveServerToolCall, Session } from '@google/genai';
import {
  CAPTURE_CHUNK_SAMPLES, INPUT_SAMPLE_RATE, OUTPUT_SAMPLE_RATE, PLAYBACK_LEAD_SEC,
  SCRIPT_PROCESSOR_BUFFER, USE_AUDIO_WORKLET, modelProfile,
} from './config';
import type { Settings } from './settings';
import { buildTools, type ToolCall } from './tools';
import { createPcmBlob, decodeBase64, pcm16ToAudioBuffer, sleep } from './utils';

export type SessionStatus = 'idle' | 'connecting' | 'listening' | 'speaking' | 'working' | 'reconnecting' | 'error';
export type StopReason = 'user' | 'background' | 'error';
export interface Turn { role: 'user' | 'model'; text: string; ts: number }
export interface ToolResponse { id?: string; name?: string; response: Record<string, unknown> }

export interface LiveSessionOptions {
  getApiKey(): string;
  getSettings(): Settings;
  buildPrompt(): { systemInstruction: string; greeting: string | null };
  nativeAvailable: boolean;
  runTool(call: ToolCall, profileId: string): Promise<ToolResponse>;
  onStatus(s: SessionStatus): void;
  onCaption(role: 'user' | 'model', text: string): void;
  onTurn(t: Turn): void;
  onError(message: string): void;
  onEnded(turns: Turn[], reason: StopReason): void;
}

const WORKLET_SRC = `
class JarvisPcmCapture extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const size = (options.processorOptions && options.processorOptions.chunk) || 320;
    this.size = size; this.buf = new Float32Array(size); this.n = 0;
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (ch) {
      for (let i = 0; i < ch.length; i++) {
        this.buf[this.n++] = ch[i];
        if (this.n === this.size) { const out = this.buf.slice(0); this.port.postMessage(out, [out.buffer]); this.n = 0; }
      }
    }
    return true;
  }
}
registerProcessor('jarvis-pcm-capture', JarvisPcmCapture);`;

export class LiveSession {
  readonly inputCtx: AudioContext;
  readonly outputCtx: AudioContext;
  readonly inputNode: GainNode;
  readonly outputNode: GainNode;

  private ai: GoogleGenAI | null = null;
  private session: Session | null = null;
  private connSeq = 0;
  private active = false;
  private ready = false;
  private setupSeen = false;
  private reconnecting = false;
  private reconnectCount = 0;
  private muted = false;
  private status: SessionStatus = 'idle';
  private resumeHandle: string | null = null;
  private greeting: string | null = null;
  private toolsInFlight = 0;
  private setupTimer: ReturnType<typeof setTimeout> | null = null;
  private cancelled = new Set<string>();

  private stream: MediaStream | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private capture: AudioNode | null = null;
  private sink: GainNode | null = null;
  private workletLoaded = false;

  private sources = new Set<AudioBufferSourceNode>();
  private nextStartTime = 0;
  private pendingUser = '';
  private pendingModel = '';
  private turns: Turn[] = [];

  constructor(private opts: LiveSessionOptions) {
    const AC: typeof AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    this.inputCtx = new AC({ sampleRate: INPUT_SAMPLE_RATE });
    this.outputCtx = new AC({ sampleRate: OUTPUT_SAMPLE_RATE });
    this.inputNode = this.inputCtx.createGain();
    this.outputNode = this.outputCtx.createGain();
    this.outputNode.connect(this.outputCtx.destination);
  }

  get isActive() { return this.active; }
  get isMuted() { return this.muted; }
  get isSpeaking() { return this.sources.size > 0; }

  /* ---------- lifecycle ---------- */
  async start(): Promise<void> {
    if (this.active) return;
    const key = this.opts.getApiKey();
    if (!key) throw new Error('NO_API_KEY');
    this.active = true; this.ready = false; this.resumeHandle = null;
    this.turns = []; this.pendingUser = this.pendingModel = ''; this.reconnectCount = 0;
    this.refresh();
    try {
      await Promise.all([this.inputCtx.resume(), this.outputCtx.resume()]);
      await this.startMic();
      this.ai = new GoogleGenAI({ apiKey: key });
      await this.openSession(false);
    } catch (e) {
      this.teardown(); this.setStatus('error'); throw e;
    }
  }

  stop(reason: StopReason = 'user') {
    if (!this.active) return;
    this.commitUser(); this.commitModel();
    const turns = this.turns; this.turns = [];
    this.teardown();
    this.setStatus('idle');
    this.opts.onEnded(turns, reason);
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.stream?.getAudioTracks().forEach((t) => (t.enabled = !m));
    if (m && this.ready) { try { this.session?.sendRealtimeInput({ audioStreamEnd: true }); } catch { /* closing */ } }
  }

  private fail(message: string) {
    if (!this.active) return;
    this.commitUser(); this.commitModel();
    const turns = this.turns; this.turns = [];
    this.teardown(); this.setStatus('error');
    this.opts.onError(message); this.opts.onEnded(turns, 'error');
  }

  private teardown() {
    this.active = false; this.ready = false; this.reconnecting = false;
    this.connSeq++; // ignore callbacks from the closing socket
    const s = this.session; this.session = null;
    try { s?.close(); } catch { /* already closed */ }
    this.clearSetupTimer(); this.interruptPlayback(); this.stopMic();
  }

  private setStatus(s: SessionStatus) { if (s !== this.status) { this.status = s; this.opts.onStatus(s); } }
  private refresh() {
    if (!this.active) return;
    this.setStatus(this.reconnecting ? 'reconnecting' : !this.ready ? 'connecting'
      : this.toolsInFlight > 0 && !this.sources.size ? 'working' : this.sources.size ? 'speaking' : 'listening');
  }

  /* ---------- connection ---------- */
  private buildConfig(s: Settings, systemInstruction: string): LiveConnectConfig {
    const profile = modelProfile(s.liveModel);
    const transcribe = s.captions || s.autoLearn || s.recallRecent;
    const config: LiveConnectConfig = {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: s.voice } } },
      systemInstruction,
      tools: buildTools(profile, { native: this.opts.nativeAvailable, googleSearch: s.googleSearch }),
      contextWindowCompression: { triggerTokens: '25000', slidingWindow: { targetTokens: '12000' } } as any,
      sessionResumption: { handle: this.resumeHandle ?? undefined },
    };
    if (transcribe) { config.inputAudioTranscription = {}; config.outputAudioTranscription = {}; }
    if (profile.thinkingLevel) (config as any).thinkingConfig = { thinkingLevel: profile.thinkingLevel };
    return config;
  }

  private async openSession(resume: boolean): Promise<void> {
    const settings = this.opts.getSettings();
    const prompt = this.opts.buildPrompt();
    const previous = this.session;
    const connId = ++this.connSeq;
    this.ready = false; this.setupSeen = false;
    this.greeting = resume ? null : prompt.greeting;
    if (!resume) this.resumeHandle = null;
    const session = await this.ai!.live.connect({
      model: settings.liveModel,
      config: this.buildConfig(settings, prompt.systemInstruction),
      callbacks: {
        onopen: () => {},
        onmessage: (m: LiveServerMessage) => { if (connId === this.connSeq) this.onMessage(m); },
        onerror: (e: ErrorEvent) => { console.warn('[jarvis] socket error', e?.message); },
        onclose: (e: CloseEvent) => { if (connId === this.connSeq) this.onClose(e); },
      },
    });
    if (connId !== this.connSeq || !this.active) { try { session.close(); } catch { /* */ } return; }
    this.session = session;
    if (previous && previous !== session) { try { previous.close(); } catch { /* */ } }
    this.clearSetupTimer();
    this.setupTimer = setTimeout(() => {
      if (connId === this.connSeq && !this.ready) this.fail('Timed out while connecting. Check your network and model in Settings.');
    }, 12000);
    if (this.setupSeen) this.afterSetup();
  }

  private clearSetupTimer() { if (this.setupTimer) { clearTimeout(this.setupTimer); this.setupTimer = null; } }

  private afterSetup() {
    this.clearSetupTimer();
    this.ready = true; this.reconnecting = false; this.reconnectCount = 0;
    this.refresh();
    const g = this.greeting; this.greeting = null;
    if (g && this.session) {
      try { this.session.sendClientContent({ turns: [{ role: 'user', parts: [{ text: g }] }], turnComplete: true }); }
      catch (e) { console.warn('[jarvis] greeting failed', e); }
    }
  }

  private onClose(e: CloseEvent) {
    if (!this.active) return;
    this.session = null; this.ready = false;
    const reason = (e.reason || '').trim();
    if (e.code === 1007 || e.code === 1008 || /api key|permission|denied|not found|not supported|invalid|quota|exhausted|billing|region|location/i.test(reason)) {
      this.fail(friendlyClose(reason, e.code)); return;
    }
    void this.reconnect();
  }

  private async reconnect() {
    if (this.reconnecting || !this.active) return;
    this.reconnecting = true; this.ready = false; this.refresh();
    if (++this.reconnectCount > 6) { this.fail('Connection lost. Tap the mic to start again.'); return; }
    const delays = [300, 1000, 2500, 5000];
    for (let i = 0; i < delays.length; i++) {
      await sleep(delays[i]);
      if (!this.active) return;
      if (!navigator.onLine) await new Promise<void>((r) => { window.addEventListener('online', () => r(), { once: true }); setTimeout(r, 20000); });
      if (i >= 1) this.resumeHandle = null; // handle may be stale: start fresh
      try { await this.openSession(this.resumeHandle !== null); this.reconnecting = false; return; }
      catch (err) { console.warn('[jarvis] reconnect failed', err); }
    }
    this.reconnecting = false;
    this.fail('Connection lost. Tap the mic to start again.');
  }

  private async onGoAway() {
    if (!this.active || this.reconnecting) return;
    this.reconnecting = true;
    try { await this.openSession(this.resumeHandle !== null); this.reconnecting = false; }
    catch {
      this.reconnecting = false;
      try { this.session?.close(); } catch { /* */ }
      this.session = null; void this.reconnect();
    }
  }

  /* ---------- server messages ---------- */
  private onMessage(m: LiveServerMessage) {
    if (m.setupComplete) { this.setupSeen = true; if (this.session) this.afterSetup(); }
    const sc = m.serverContent;
    if (sc) {
      if (sc.interrupted) { this.interruptPlayback(); this.commitModel(); }
      for (const part of sc.modelTurn?.parts ?? []) {
        const inline = part.inlineData;
        if (inline?.data && (!inline.mimeType || inline.mimeType.startsWith('audio/'))) {
          const rate = Number(/rate=(\d+)/.exec(inline.mimeType ?? '')?.[1]) || OUTPUT_SAMPLE_RATE;
          this.playChunk(inline.data, rate);
        }
      }
      if (sc.inputTranscription?.text) this.appendUser(sc.inputTranscription.text);
      if (sc.outputTranscription?.text) this.appendModel(sc.outputTranscription.text);
      if (sc.turnComplete) { this.commitModel(); this.commitUser(); this.refresh(); }
    }
    if (m.toolCall) void this.onToolCall(m.toolCall);
    for (const id of m.toolCallCancellation?.ids ?? []) this.cancelled.add(id);
    const u = m.sessionResumptionUpdate;
    if (u?.resumable && u.newHandle) this.resumeHandle = u.newHandle;
    if (m.goAway) void this.onGoAway();
  }

  private async onToolCall(tc: LiveServerToolCall) {
    const calls = tc.functionCalls ?? [];
    if (!calls.length) return;
    const connId = this.connSeq, n = calls.length;
    this.toolsInFlight += n; this.refresh();
    let out: ToolResponse[] = [];
    try {
      out = await Promise.all(calls.map((c) =>
        this.opts.runTool({ id: c.id, name: c.name, args: (c.args ?? {}) as Record<string, unknown> }, this.opts.getSettings().liveModel)));
    } finally { this.toolsInFlight -= n; this.refresh(); }
    if (connId !== this.connSeq || !this.session) return;
    const live = out.filter((r) => !r.id || !this.cancelled.has(r.id));
    if (live.length) { try { this.session.sendToolResponse({ functionResponses: live }); } catch (e) { console.warn(e); } }
  }

  /* ---------- transcripts ---------- */
  private appendUser(t: string) {
    if (this.pendingModel) this.commitModel();
    if (!this.pendingUser) this.opts.onCaption('model', '');
    this.pendingUser += t; this.opts.onCaption('user', this.pendingUser);
  }
  private appendModel(t: string) {
    if (this.pendingUser) this.commitUser();
    this.pendingModel += t; this.opts.onCaption('model', this.pendingModel);
  }
  private commit(role: 'user' | 'model', text: string) {
    const t = text.trim(); if (!t) return;
    const turn = { role, text: t, ts: Date.now() };
    this.turns.push(turn); this.opts.onTurn(turn);
  }
  private commitUser() { this.commit('user', this.pendingUser); this.pendingUser = ''; }
  private commitModel() { this.commit('model', this.pendingModel); this.pendingModel = ''; }

  /* ---------- playback ---------- */
  private playChunk(b64: string, rate: number) {
    const bytes = decodeBase64(b64);
    if (bytes.byteLength < 2) return;
    if (this.pendingUser) this.commitUser();
    const ctx = this.outputCtx;
    const buffer = pcm16ToAudioBuffer(bytes, ctx, rate);
    this.nextStartTime = Math.max(this.nextStartTime, ctx.currentTime + (this.sources.size === 0 ? PLAYBACK_LEAD_SEC : 0));
    const src = ctx.createBufferSource();
    src.buffer = buffer; src.connect(this.outputNode);
    src.onended = () => { this.sources.delete(src); this.refresh(); };
    src.start(this.nextStartTime);
    this.nextStartTime += buffer.duration;
    this.sources.add(src); this.refresh();
  }

  /** Barge-in: stop everything that is queued or playing and go back to listening. */
  private interruptPlayback() {
    for (const s of this.sources) {
      s.onended = null;
      try { s.stop(); } catch { /* not started */ }
      try { s.disconnect(); } catch { /* */ }
    }
    this.sources.clear(); this.nextStartTime = 0; this.refresh();
  }

  /* ---------- microphone ---------- */
  private sendAudio(chunk: Float32Array) {
    if (!this.ready || !this.session || this.muted) return;
    if (this.opts.getSettings().echoGuard && this.sources.size > 0) return;
    try { this.session.sendRealtimeInput({ audio: createPcmBlob(chunk) }); } catch { /* socket closing */ }
  }

  private async startMic() {
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 }, video: false,
    });
    const ctx = this.inputCtx;
    this.source = ctx.createMediaStreamSource(this.stream);
    this.source.connect(this.inputNode);
    this.sink = ctx.createGain(); this.sink.gain.value = 0; this.sink.connect(ctx.destination);
    let done = false;
    if (USE_AUDIO_WORKLET && ctx.audioWorklet) {
      try {
        if (!this.workletLoaded) {
          const url = URL.createObjectURL(new Blob([WORKLET_SRC], { type: 'application/javascript' }));
          try { await ctx.audioWorklet.addModule(url); } finally { URL.revokeObjectURL(url); }
          this.workletLoaded = true;
        }
        const node = new AudioWorkletNode(ctx, 'jarvis-pcm-capture', { numberOfInputs: 1, numberOfOutputs: 1, channelCount: 1, processorOptions: { chunk: CAPTURE_CHUNK_SAMPLES } });
        node.port.onmessage = (ev) => this.sendAudio(ev.data as Float32Array);
        this.source.connect(node); node.connect(this.sink); this.capture = node; done = true;
      } catch (e) { console.warn('[jarvis] AudioWorklet unavailable, using ScriptProcessor', e); }
    }
    if (!done) {
      const sp = ctx.createScriptProcessor(SCRIPT_PROCESSOR_BUFFER, 1, 1);
      sp.onaudioprocess = (ev) => this.sendAudio(ev.inputBuffer.getChannelData(0));
      this.source.connect(sp); sp.connect(this.sink); this.capture = sp;
    }
    this.stream.getAudioTracks().forEach((t) => (t.enabled = !this.muted));
  }

  private stopMic() {
    const c = this.capture;
    if (c instanceof AudioWorkletNode) c.port.onmessage = null;
    else if (c) (c as ScriptProcessorNode).onaudioprocess = null;
    for (const n of [c, this.source, this.sink]) { try { n?.disconnect(); } catch { /* */ } }
    this.stream?.getTracks().forEach((t) => t.stop());
    this.capture = this.source = this.sink = null; this.stream = null;
  }
}

function friendlyClose(reason: string, code: number): string {
  if (/api key/i.test(reason)) return 'Your API key was rejected. Check it in Settings.';
  if (/not found|not supported/i.test(reason)) return 'That Live model is not available for your key. Pick another in Settings, Advanced.';
  if (/quota|exhausted|billing/i.test(reason)) return 'Your Gemini quota or billing blocks this request.';
  return reason ? reason.slice(0, 160) : `Connection closed (${code}).`;
}
