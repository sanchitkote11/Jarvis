import { DEFAULT_ACCENT_VALUE } from './settings-defaults';
import { LIVE_MODEL, TEXT_MODEL } from './config';
import { native } from './native';
import { storage } from './storage';

export type Persona = 'jarvis' | 'friendly' | 'concise';
export interface Settings {
  userName: string; voice: string; persona: Persona; accent: string;
  autoLearn: boolean; recallRecent: boolean; captions: boolean; greet: boolean;
  googleSearch: boolean; echoGuard: boolean; haptics: boolean;
  liveModel: string; textModel: string;
}

export const DEFAULT_SETTINGS: Settings = {
  userName: '', voice: 'Orus', persona: 'jarvis', accent: DEFAULT_ACCENT_VALUE,
  autoLearn: true, recallRecent: true, captions: true, greet: true,
  googleSearch: true, echoGuard: false, haptics: true,
  liveModel: LIVE_MODEL, textModel: TEXT_MODEL,
};

const KEY = 'jarvis.settings.v1';
export const loadSettings = (): Settings => ({ ...DEFAULT_SETTINGS, ...storage.getJSON<Partial<Settings>>(KEY, {}) });
export const saveSettings = (s: Settings) => storage.setJSON(KEY, s);

const WEB_KEY = 'jarvis.apiKey';
export function resolveApiKey(): string {
  const nativeKey = native.getApiKey();
  if (nativeKey) return nativeKey;
  try { const saved = localStorage.getItem(WEB_KEY); if (saved) return saved; } catch { /* ignore */ }
  try { return process.env.GEMINI_API_KEY || ''; } catch { return ''; }
}
export function saveApiKey(key: string) {
  const k = key.trim();
  if (native.available) native.setApiKey(k);
  else { try { k ? localStorage.setItem(WEB_KEY, k) : localStorage.removeItem(WEB_KEY); } catch { /* ignore */ } }
}
