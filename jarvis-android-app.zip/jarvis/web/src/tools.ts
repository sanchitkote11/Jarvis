import { Behavior, Type } from '@google/genai';
import type { FunctionDeclaration, Tool } from '@google/genai';
import type { ModelProfile } from './config';
import { asCategory, type MemoryStore } from './memory';
import { native } from './native';

export interface ToolCall { id?: string; name?: string; args?: Record<string, unknown> }
export interface ToolContext {
  memory: MemoryStore;
  setAccent(color: string): boolean;
  saved(text: string, status: string): void;
}
type Result = Record<string, unknown>;
interface ToolDef {
  decl: FunctionDeclaration; mode: 'silent' | 'blocking'; nativeOnly?: boolean;
  run(args: Record<string, unknown>, ctx: ToolContext): Result | Promise<Result>;
}

const str = (v: unknown) => (typeof v === 'string' ? v.trim() : '');
const int = (v: unknown, lo: number, hi: number, d: number) => {
  const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d;
};
const obj = (properties: Record<string, object>, required: string[] = []) =>
  ({ type: Type.OBJECT, properties, required } as FunctionDeclaration['parameters']);
const S = (description: string, extra: object = {}) => ({ type: Type.STRING, description, ...extra });
const N = (description: string) => ({ type: Type.INTEGER, description });

const TOOLS: ToolDef[] = [
  {
    mode: 'silent',
    decl: {
      name: 'remember_fact',
      description: 'Save something about the user to long-term memory. Invoke as soon as the user shares a like, dislike, preference, personal fact, person in their life, routine, goal or project, or asks you to remember something. Write one short third-person sentence. Never invoke for secrets, passwords or card numbers, or for trivia and one-off requests.',
      parameters: obj({
        fact: S('One short third-person sentence, e.g. "Loves spicy ramen."'),
        category: S('Kind of fact.', { enum: ['like', 'dislike', 'preference', 'fact', 'person', 'goal', 'other'] }),
        importance: N('1 minor, 2 useful, 3 core to who they are.'),
        replaces: S('Only if this updates something already known: a few words describing the old fact.'),
      }, ['fact', 'category']),
    },
    run(a, ctx) {
      const fact = str(a.fact);
      if (!fact) return { ok: false, error: 'No fact given.' };
      const r = ctx.memory.add(fact, asCategory(a.category), {
        importance: int(a.importance, 1, 3, 2) as 1 | 2 | 3, replaces: str(a.replaces) || undefined, source: 'voice' });
      if (r.status === 'rejected') return { ok: false, error: r.reason };
      ctx.saved(r.item.text, r.status);
      return { ok: true, status: r.status, saved: r.item.text };
    },
  },
  {
    mode: 'blocking',
    decl: {
      name: 'recall_memories',
      description: 'Look up saved memories about the user. Invoke when they ask what you know or remember about them or a topic, or when you need a personal detail not already in KNOWN FACTS.',
      parameters: obj({ query: S('Topic or keywords. Leave empty for the most important memories.') }),
    },
    run(a, ctx) {
      const found = ctx.memory.search(str(a.query), 12);
      return { ok: true, count: found.length, memories: found.map((m) => ({ text: m.text, category: m.category })) };
    },
  },
  {
    mode: 'blocking',
    decl: {
      name: 'forget_fact',
      description: 'Delete saved memories matching a description. Invoke only when the user asks you to forget or stop remembering something. Afterwards tell them what was removed.',
      parameters: obj({ query: S('Words describing the memory to delete.') }, ['query']),
    },
    run(a, ctx) {
      const hits = ctx.memory.matching(str(a.query));
      if (!hits.length) return { ok: false, error: 'No matching memory found.' };
      if (hits.length > 5) return { ok: false, error: 'Too many matches. Ask the user to be more specific.', candidates: hits.slice(0, 5).map((m) => m.text) };
      ctx.memory.removeIds(hits.map((m) => m.id));
      return { ok: true, removed: hits.map((m) => m.text) };
    },
  },
  {
    mode: 'blocking',
    decl: { name: 'get_current_time', description: 'Get the current local date, time and timezone. Invoke when the user asks the time or date, or for long sessions.' },
    run() {
      const d = new Date();
      return { ok: true, local: d.toLocaleString(), weekday: d.toLocaleDateString(undefined, { weekday: 'long' }),
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, iso: d.toISOString() };
    },
  },
  {
    mode: 'blocking',
    decl: { name: 'get_battery_status', description: 'Get the phone battery level and charging state. Invoke when the user asks about battery.' },
    async run() {
      const b = native.battery();
      if (b) return { ok: true, ...b };
      const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number; charging: boolean }> };
      if (nav.getBattery) { const x = await nav.getBattery(); return { ok: true, level: Math.round(x.level * 100), charging: x.charging }; }
      return { ok: false, error: 'Battery status is not available.' };
    },
  },
  {
    mode: 'blocking',
    decl: {
      name: 'set_orb_color',
      description: 'Change the glow color of the on-screen orb. Invoke when the user asks for a different orb or glow color.',
      parameters: obj({ color: S('CSS color name or hex value such as "orange" or "#ff6a00".') }, ['color']),
    },
    run(a, ctx) {
      const c = str(a.color);
      return ctx.setAccent(c) ? { ok: true, color: c } : { ok: false, error: 'Not a valid color.' };
    },
  },
  {
    mode: 'blocking', nativeOnly: true,
    decl: { name: 'set_timer', description: 'Start a countdown timer on the phone. Invoke when the user asks for a timer.',
      parameters: obj({ seconds: N('Duration in seconds.'), label: S('Optional label.') }, ['seconds']) },
    run: (a) => ({ ok: native.setTimer(int(a.seconds, 1, 86400, 60), str(a.label)) }),
  },
  {
    mode: 'blocking', nativeOnly: true,
    decl: { name: 'set_alarm', description: 'Set an alarm on the phone for a clock time. Invoke when the user asks for an alarm.',
      parameters: obj({ hour: N('Hour 0-23.'), minute: N('Minute 0-59.'), label: S('Optional label.') }, ['hour', 'minute']) },
    run: (a) => ({ ok: native.setAlarm(int(a.hour, 0, 23, 7), int(a.minute, 0, 59, 0), str(a.label)) }),
  },
  {
    mode: 'blocking', nativeOnly: true,
    decl: { name: 'toggle_flashlight', description: 'Turn the phone flashlight on or off. Invoke when the user asks.',
      parameters: obj({ on: { type: Type.BOOLEAN, description: 'true to turn on, false to turn off.' } }, ['on']) },
    run: (a) => ({ ok: native.torch(a.on === true || a.on === 'true') }),
  },
  {
    mode: 'blocking', nativeOnly: true,
    decl: { name: 'open_url', description: 'Open a web page in the phone browser. Invoke only when the user asks to open or show a site.',
      parameters: obj({ url: S('Full http or https address.') }, ['url']) },
    run(a) {
      try { const u = new URL(str(a.url)); if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('scheme'); return { ok: native.openUrl(u.toString()) }; }
      catch { return { ok: false, error: 'Invalid web address.' }; }
    },
  },
  {
    mode: 'blocking', nativeOnly: true,
    decl: { name: 'open_maps', description: 'Show a place or directions in the maps app. Invoke when the user asks to find or navigate to a place.',
      parameters: obj({ query: S('Place name or address.') }, ['query']) },
    run: (a) => ({ ok: native.openMaps(str(a.query)) }),
  },
  {
    mode: 'blocking', nativeOnly: true,
    decl: { name: 'share_text', description: 'Open the phone share sheet with some text (a note, list or draft) so the user can send or save it. Invoke only when asked.',
      parameters: obj({ text: S('Text to share.') }, ['text']) },
    run: (a) => ({ ok: native.share(str(a.text)) }),
  },
];

export function buildTools(profile: ModelProfile, o: { native: boolean; googleSearch: boolean }): Tool[] {
  const functionDeclarations = TOOLS.filter((t) => !t.nativeOnly || o.native).map((t) => {
    const decl: FunctionDeclaration = { ...t.decl };
    if (profile.async === 'optional') decl.behavior = t.mode === 'silent' ? Behavior.NON_BLOCKING : Behavior.BLOCKING;
    return decl;
  });
  const tools: Tool[] = [{ functionDeclarations }];
  if (o.googleSearch) tools.push({ googleSearch: {} });
  return tools;
}

export async function executeTool(call: ToolCall, ctx: ToolContext, profile: ModelProfile) {
  const def = TOOLS.find((t) => t.decl.name === call.name);
  let result: Result;
  try { result = def ? await def.run(call.args ?? {}, ctx) : { ok: false, error: `Unknown tool ${call.name}` }; }
  catch (e) { result = { ok: false, error: String((e as Error)?.message ?? e) }; }
  const response: Result = { result };
  if (profile.async === 'optional' && def?.mode === 'silent') {
    response.scheduling = result.ok ? 'SILENT' : 'WHEN_IDLE';
  }
  return { id: call.id, name: call.name, response };
}
