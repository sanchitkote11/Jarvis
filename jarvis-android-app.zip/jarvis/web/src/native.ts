/** Thin, failure-proof wrapper around the Android WebView bridge (window.AndroidBridge). */
interface AndroidBridgeApi {
  getApiKey(): string; setApiKey(key: string): void;
  kvGet(key: string): string | null; kvSet(key: string, value: string): void; kvRemove(key: string): void;
  setKeepScreenOn(on: boolean): void; setBackHandled(on: boolean): void; vibrate(ms: number): void;
  getBatteryInfo(): string; setTimer(seconds: number, label: string): boolean;
  setAlarm(hour: number, minute: number, label: string): boolean;
  openUrl(url: string): boolean; openMaps(query: string): boolean; shareText(text: string): boolean;
  setTorch(on: boolean): boolean; getDeviceInfo(): string; openAppSettings(): void;
}
declare global {
  interface Window { AndroidBridge?: AndroidBridgeApi; __jarvisBack?: () => boolean }
}

function call<T>(fn: (b: AndroidBridgeApi) => T, fallback: T): T {
  try { const b = window.AndroidBridge; return b ? fn(b) : fallback; } catch { return fallback; }
}
const parse = (s: string) => { try { return JSON.parse(s); } catch { return null; } };

export const native = {
  get available() { return !!window.AndroidBridge; },
  getApiKey: () => call((b) => b.getApiKey() || '', ''),
  setApiKey: (k: string) => call((b) => b.setApiKey(k), undefined),
  kvGet: (k: string) => call((b) => b.kvGet(k), null as string | null),
  kvSet: (k: string, v: string) => call((b) => b.kvSet(k, v), undefined),
  kvRemove: (k: string) => call((b) => b.kvRemove(k), undefined),
  keepScreenOn: (on: boolean) => call((b) => b.setKeepScreenOn(on), undefined),
  setBackHandled: (on: boolean) => call((b) => b.setBackHandled(on), undefined),
  vibrate: (ms: number) => call((b) => b.vibrate(ms), undefined),
  battery: () => call((b) => parse(b.getBatteryInfo()) as { level: number; charging: boolean } | null, null),
  setTimer: (s: number, label: string) => call((b) => b.setTimer(s, label), false),
  setAlarm: (h: number, m: number, label: string) => call((b) => b.setAlarm(h, m, label), false),
  openUrl: (u: string) => call((b) => b.openUrl(u), false),
  openMaps: (q: string) => call((b) => b.openMaps(q), false),
  share: (t: string) => call((b) => b.shareText(t), false),
  torch: (on: boolean) => call((b) => b.setTorch(on), false),
  openAppSettings: () => call((b) => b.openAppSettings(), undefined),
};
