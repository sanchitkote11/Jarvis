import { LitElement, html, nothing } from 'lit';
import { iconClose, iconTrash } from './icons';
import { CATEGORIES, asCategory, type MemoryCategory, type MemoryStore } from './memory';
import { native } from './native';
import { baseStyles, sheetStyles } from './ui-styles';
import { timeAgo } from './utils';
import { css } from 'lit';

export class JarvisMemorySheet extends LitElement {
  static properties = {
    open: { type: Boolean, reflect: true }, store: { attribute: false },
    query: { state: true }, draft: { state: true }, cat: { state: true },
    importing: { state: true }, importText: { state: true }, confirm: { state: true }, note: { state: true },
  };
  declare open: boolean; declare store: MemoryStore | null;
  declare query: string; declare draft: string; declare cat: MemoryCategory;
  declare importing: boolean; declare importText: string; declare confirm: boolean; declare note: string;

  static styles = [baseStyles, sheetStyles, css`
    .row { display: flex; align-items: flex-start; gap: 8px; padding: 11px 0; border-bottom: 1px solid var(--line); }
    .row .t { flex: 1; font-size: 14px; line-height: 1.45; -webkit-user-select: text; user-select: text; }
    .row .w { font-size: 11px; color: var(--haze); white-space: nowrap; padding-top: 3px; }
    .row button { color: var(--haze); width: 32px; height: 32px; display: grid; place-items: center; border-radius: 50%; }
    .add { display: grid; grid-template-columns: 1fr auto; gap: 8px; margin-bottom: 8px; }
    .add select { grid-column: 1 / 3; }
    .empty { padding: 28px 4px; color: var(--haze); font-size: 14px; line-height: 1.6; }
    .actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 24px; }
  `];

  constructor() {
    super();
    this.open = false; this.store = null; this.query = ''; this.draft = ''; this.cat = 'like';
    this.importing = false; this.importText = ''; this.confirm = false; this.note = '';
  }
  private onChange = () => this.requestUpdate();
  protected updated(c: Map<string, unknown>) {
    if (c.has('store')) {
      (c.get('store') as MemoryStore | undefined)?.removeEventListener('change', this.onChange);
      this.store?.addEventListener('change', this.onChange);
    }
  }
  private close() { this.dispatchEvent(new CustomEvent('close', { bubbles: true, composed: true })); }
  private add() {
    const r = this.store?.add(this.draft, this.cat, { importance: 2, source: 'manual' });
    if (r?.status === 'rejected') this.note = r.reason; else { this.note = ''; this.draft = ''; }
  }
  private async exportAll() {
    const json = this.store!.exportJSON();
    if (native.available && native.share(json)) return;
    try { await navigator.clipboard.writeText(json); this.note = 'Copied to the clipboard.'; } catch { this.note = 'Could not copy.'; }
  }
  private doImport() {
    try { const r = this.store!.importJSON(this.importText); this.note = `Added ${r.added}, skipped ${r.skipped}.`; this.importing = false; this.importText = ''; }
    catch { this.note = 'That does not look like a Jarvis memory export.'; }
  }
  private wipe() {
    if (!this.confirm) { this.confirm = true; setTimeout(() => (this.confirm = false), 4000); return; }
    this.store?.clear(); this.confirm = false;
  }

  render() {
    const all = this.store?.list() ?? [];
    const q = this.query.trim().toLowerCase();
    const items = q ? all.filter((m) => m.text.toLowerCase().includes(q)) : all;
    return html`
      <div class="scrim" @click=${this.close}></div>
      <section class="panel" role="dialog" aria-label="Memory" ?inert=${!this.open}>
        <header><h2>Memory</h2><button class="icon-btn" aria-label="Close" @click=${this.close}>${iconClose}</button></header>
        <div class="body">
          <p class="sub">What Jarvis knows about you. It stays on this device and is shared with Gemini only as conversation context.</p>
          <div class="add">
            <input type="text" placeholder="Add something to remember" .value=${this.draft} maxlength="280"
              @input=${(e: Event) => (this.draft = (e.target as HTMLInputElement).value)}
              @keydown=${(e: KeyboardEvent) => e.key === 'Enter' && this.add()} />
            <button class="pill primary" @click=${this.add}>Save</button>
            <select .value=${this.cat} @change=${(e: Event) => (this.cat = asCategory((e.target as HTMLSelectElement).value))}>
              ${CATEGORIES.map((c) => html`<option value=${c.id} ?selected=${c.id === this.cat}>${c.label}</option>`)}
            </select>
          </div>
          ${this.note ? html`<small>${this.note}</small>` : nothing}
          ${all.length > 6 ? html`<div style="margin-top:10px"><input type="text" placeholder="Search memories" .value=${this.query}
            @input=${(e: Event) => (this.query = (e.target as HTMLInputElement).value)} /></div>` : nothing}
          ${!all.length ? html`<div class="empty">Nothing here yet. Tell Jarvis what you love, or say “remember that…”.</div>` : nothing}
          ${CATEGORIES.map((c) => {
            const g = items.filter((m) => m.category === c.id);
            return g.length ? html`<h3>${c.label}</h3>${g.map((m) => html`
              <div class="row"><span class="t">${m.text}</span><span class="w">${timeAgo(m.updatedAt)}</span>
                <button aria-label="Forget this" @click=${() => this.store?.remove(m.id)}>${iconTrash}</button></div>`)}` : nothing;
          })}
          ${this.importing ? html`<h3>Paste an export</h3><textarea .value=${this.importText} @input=${(e: Event) => (this.importText = (e.target as HTMLTextAreaElement).value)}></textarea>
            <div class="actions"><button class="pill primary" @click=${this.doImport}>Add to memory</button><button class="pill" @click=${() => (this.importing = false)}>Cancel</button></div>` : nothing}
          <div class="actions">
            <button class="pill" @click=${this.exportAll} ?disabled=${!all.length}>Export</button>
            <button class="pill" @click=${() => (this.importing = !this.importing)}>Import</button>
            ${all.length ? html`<button class="pill danger" @click=${this.wipe}>${this.confirm ? 'Tap again to confirm' : 'Forget everything'}</button>` : nothing}
          </div>
        </div>
      </section>`;
  }
}
customElements.define('jarvis-memory-sheet', JarvisMemorySheet);
