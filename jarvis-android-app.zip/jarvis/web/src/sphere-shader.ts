import { Vector4 } from 'three';

/** GLSL injected into MeshStandardMaterial's vertex shader. */
const HEADER = /* glsl */ `
uniform float time;
uniform vec4 inputData;
uniform vec4 outputData;

vec3 jarvisCalc( vec3 pos ) {
  vec3 dir = normalize( pos );
  return pos +
    ( inputData.x * inputData.y * dir * ( 0.5 + 0.5 * sin( inputData.z * pos.x + time ) ) ) +
    ( outputData.x * outputData.y * dir * ( 0.5 + 0.5 * sin( outputData.z * pos.y + time ) ) );
}

// Normal from finite differences along a spherical tangent / bitangent.
vec3 jarvisNormal( vec3 pos ) {
  vec3 n = normalize( pos );
  vec3 helper = abs( n.y ) < 0.99 ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
  vec3 tangent = normalize( cross( helper, n ) );
  vec3 bitangent = normalize( cross( n, tangent ) );
  float eps = 0.02;
  float r = length( pos );
  vec3 p0 = jarvisCalc( pos );
  vec3 p1 = jarvisCalc( normalize( pos + tangent * eps ) * r );
  vec3 p2 = jarvisCalc( normalize( pos + bitangent * eps ) * r );
  vec3 nn = normalize( cross( p1 - p0, p2 - p0 ) );
  return dot( nn, n ) < 0.0 ? -nn : nn;
}
`;

type ShaderLike = { uniforms: Record<string, { value: unknown }>; vertexShader: string };

/** Use as material.onBeforeCompile. Patches the built-in shader so it survives three.js upgrades. */
export function applySphereShader(shader: ShaderLike) {
  shader.uniforms.time = { value: 0 };
  shader.uniforms.inputData = { value: new Vector4() };
  shader.uniforms.outputData = { value: new Vector4() };
  shader.vertexShader = shader.vertexShader
    .replace('#include <common>', '#include <common>\n' + HEADER)
    .replace('#include <beginnormal_vertex>', '#include <beginnormal_vertex>\n  objectNormal = jarvisNormal( position );')
    .replace('#include <begin_vertex>', '#include <begin_vertex>\n  transformed = jarvisCalc( position );');
}
