import { LitElement, css, html, nothing } from 'lit';
import { iconClose } from './icons';
import type { ConversationLog } from './memory';
import { baseStyles, sheetStyles } from './ui-styles';

export class JarvisLogSheet extends LitElement {
  static properties = { open: { type: Boolean, reflect: true }, log: { attribute: false } };
  declare open: boolean; declare log: ConversationLog | null;
  static styles = [baseStyles, sheetStyles, css`
    .msg { padding: 10px 0; border-bottom: 1px solid var(--line); font-size: 14px; line-height: 1.5; -webkit-user-select: text; user-select: text; }
    .who { font-size: 12px; font-weight: 600; color: var(--haze); margin-bottom: 2px; }
    .msg.model .who { color: var(--accent); }
    .empty { padding: 28px 4px; color: var(--haze); font-size: 14px; }
  `];
  constructor() { super(); this.open = false; this.log = null; }
  private onChange = () => this.requestUpdate();
  protected updated(c: Map<string, unknown>) {
    if (c.has('log')) { (c.get('log') as ConversationLog | undefined)?.removeEventListener('change', this.onChange); this.log?.addEventListener('change', this.onChange); }
    if (c.has('open') && this.open) this.renderRoot.querySelector('.body')?.scrollTo(0, 1e9);
  }
  private close() { this.dispatchEvent(new CustomEvent('close', { bubbles: true, composed: true })); }
  render() {
    const items = this.log?.all() ?? [];
    return html`<div class="scrim" @click=${this.close}></div>
      <section class="panel" role="dialog" aria-label="Conversation" ?inert=${!this.open}>
        <header><h2>Conversation</h2><button class="icon-btn" aria-label="Close" @click=${this.close}>${iconClose}</button></header>
        <div class="body">
          ${items.length ? items.map((m) => html`<div class="msg ${m.role}"><div class="who">${m.role === 'user' ? 'You' : 'Jarvis'}</div>${m.text}</div>`)
            : html`<div class="empty">Your recent conversations will show up here.</div>`}
          ${items.length ? html`<div style="margin-top:20px"><button class="pill danger" @click=${() => this.log?.clear()}>Clear conversation</button></div>` : nothing}
        </div>
      </section>`;
  }
}
customElements.define('jarvis-log-sheet', JarvisLogSheet);
