export const DEFAULT_ACCENT_VALUE = '#4d7cff';
