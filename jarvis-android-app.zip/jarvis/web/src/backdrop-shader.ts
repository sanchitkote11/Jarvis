// No #version line: three adds it because the material uses glslVersion GLSL3.
export const vs = /* glsl */ `
precision highp float;
in vec3 position;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
void main() {
  gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1. );
}
`;

export const fs = /* glsl */ `
precision highp float;
out vec4 fragmentColor;
uniform vec2 resolution;
uniform float rand;
uniform vec3 tint;

void main() {
  float aspectRatio = resolution.x / resolution.y;
  vec2 vUv = gl_FragCoord.xy / resolution;
  float noise = fract( sin( dot( vUv, vec2( 12.9898 + rand, 78.233 ) * 2.0 ) ) * 43758.5453 );
  vUv -= .5;
  vUv.x *= aspectRatio;
  float d = 4. * length( vUv );
  vec3 from = vec3( 3. ) / 255.;
  vec3 to = vec3( 16., 12., 20. ) / 2. / 255. + tint * 0.02;
  fragmentColor = vec4( mix( from, to, d ) + .005 * noise, 1. );
}
`;
