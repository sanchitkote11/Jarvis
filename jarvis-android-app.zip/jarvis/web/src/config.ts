export const APP_NAME = 'Jarvis';
export const APP_VERSION = '1.0.0';

// Model names change often. If connecting fails with "model not found",
// open Settings > Advanced and pick another one (or type an ID).
export const LIVE_MODEL = 'gemini-3.8-live';
export const TEXT_MODEL = 'gemini-3.8-flash'; // background learning only

export const LIVE_MODEL_PRESETS: ReadonlyArray<{ id: string; label: string }> = [
  { id: 'gemini-3.8-live', label: 'Gemini 3.8 Live (fast, default)' },
  { id: 'gemini-3.8-live-extended-thinking', label: 'Gemini 3.8 Live, extended thinking' },
  { id: 'gemini-3.1-flash-live-preview', label: 'Gemini 3.1 Flash Live (older preview)' },
];

export interface ModelProfile {
  /** none: one tool call at a time. optional: blocking or async per tool. only: async only. */
  async: 'none' | 'optional' | 'only';
  thinkingLevel?: 'low';
}

export function modelProfile(id: string): ModelProfile {
  if (id.includes('extended-thinking')) return { async: 'only', thinkingLevel: 'low' };
  const m = /^gemini-(\d+)\.(\d+)-live/.exec(id);
  if (m && Number(m[1]) * 100 + Number(m[2]) >= 308) return { async: 'optional' };
  return { async: 'none' };
}

export const VOICES: ReadonlyArray<{ name: string; tone: string }> = [
  ['Orus', 'Firm'], ['Charon', 'Informative'], ['Iapetus', 'Clear'], ['Algieba', 'Smooth'],
  ['Gacrux', 'Mature'], ['Kore', 'Firm'], ['Puck', 'Upbeat'], ['Fenrir', 'Excitable'],
  ['Aoede', 'Breezy'], ['Zephyr', 'Bright'], ['Leda', 'Youthful'], ['Callirrhoe', 'Easy-going'],
  ['Autonoe', 'Bright'], ['Enceladus', 'Breathy'], ['Umbriel', 'Easy-going'], ['Despina', 'Smooth'],
  ['Erinome', 'Clear'], ['Algenib', 'Gravelly'], ['Rasalgethi', 'Informative'], ['Laomedeia', 'Upbeat'],
  ['Achernar', 'Soft'], ['Alnilam', 'Firm'], ['Schedar', 'Even'], ['Pulcherrima', 'Forward'],
  ['Achird', 'Friendly'], ['Zubenelgenubi', 'Casual'], ['Vindemiatrix', 'Gentle'],
  ['Sadachbia', 'Lively'], ['Sadaltager', 'Knowledgeable'], ['Sulafat', 'Warm'],
].map(([name, tone]) => ({ name, tone }));

export const ACCENTS: ReadonlyArray<{ name: string; value: string }> = [
  { name: 'Arc blue', value: '#4d7cff' }, { name: 'Ion cyan', value: '#22d3ee' },
  { name: 'Jade', value: '#34d399' }, { name: 'Gold', value: '#fbbf24' },
  { name: 'Ember', value: '#ff7a3d' }, { name: 'Rose', value: '#ff5d9e' },
  { name: 'Violet', value: '#9b6bff' }, { name: 'Ice', value: '#cfe2ff' },
];

export const INPUT_SAMPLE_RATE = 16000;
export const OUTPUT_SAMPLE_RATE = 24000;
export const CAPTURE_CHUNK_SAMPLES = 320; // 20 ms at 16 kHz
export const SCRIPT_PROCESSOR_BUFFER = 256; // fallback path, per spec
export const USE_AUDIO_WORKLET = true; // false forces ScriptProcessorNode(256)
export const PLAYBACK_LEAD_SEC = 0.04;

export const ORB = { bloomStrength: 5, bloomRadius: 0.5, bloomThreshold: 0, maxPixelRatio: 2, detail: 10 };
