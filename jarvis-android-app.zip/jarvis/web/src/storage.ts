import { native } from './native';

/** Android: SharedPreferences (backed up by Android). Web: localStorage. */
export const storage = {
  get(key: string): string | null {
    if (native.available) return native.kvGet(key);
    try { return localStorage.getItem(key); } catch { return null; }
  },
  set(key: string, value: string) {
    if (native.available) return native.kvSet(key, value);
    try { localStorage.setItem(key, value); } catch { /* storage full or blocked */ }
  },
  remove(key: string) {
    if (native.available) return native.kvRemove(key);
    try { localStorage.removeItem(key); } catch { /* ignore */ }
  },
  getJSON<T>(key: string, fallback: T): T {
    const raw = this.get(key);
    if (!raw) return fallback;
    try { return JSON.parse(raw) as T; } catch { return fallback; }
  },
  setJSON(key: string, value: unknown) { this.set(key, JSON.stringify(value)); },
};
