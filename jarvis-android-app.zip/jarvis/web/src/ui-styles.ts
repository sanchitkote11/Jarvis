import { css } from 'lit';

export const baseStyles = css`
  :host { font-family: var(--font); color: var(--ink); }
  button, input, select, textarea { font: inherit; color: inherit; }
  button { cursor: pointer; border: 0; background: none; padding: 0; }
  :focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
  .icon-btn { width: 44px; height: 44px; border-radius: 50%; display: grid; place-items: center; color: var(--ink); }
  .icon-btn:active { background: rgba(255,255,255,.08); }
  .pill { height: 40px; padding: 0 18px; border-radius: 999px; border: 1px solid var(--line); background: rgba(255,255,255,.04); font-weight: 600; font-size: 13px; }
  .pill.primary { background: var(--accent); border-color: transparent; color: #04060f; }
  .pill.danger { color: var(--danger); }
  input[type=text], input[type=password], select, textarea {
    width: 100%; height: 44px; padding: 0 14px; border-radius: 12px; border: 1px solid var(--line);
    background: rgba(255,255,255,.04); font-size: 14px; -webkit-user-select: text; user-select: text;
  }
  textarea { height: 120px; padding: 12px 14px; resize: none; }
  select option { background: #10142a; }
  small, .muted { color: var(--haze); font-size: 12px; }
`;

export const sheetStyles = css`
  .scrim { position: fixed; inset: 0; background: rgba(2,3,8,.55); opacity: 0; pointer-events: none; transition: opacity .22s; }
  .panel {
    position: fixed; left: 0; right: 0; bottom: 0; max-height: 86%; display: flex; flex-direction: column;
    background: var(--glass-strong); border-top: 1px solid var(--line); border-radius: 24px 24px 0 0;
    backdrop-filter: blur(18px); -webkit-backdrop-filter: blur(18px);
    transform: translateY(104%); transition: transform .26s cubic-bezier(.2,.8,.2,1); visibility: hidden;
  }
  :host([open]) .scrim { opacity: 1; pointer-events: auto; }
  :host([open]) .panel { transform: none; visibility: visible; }
  header { display: flex; align-items: center; justify-content: space-between; padding: 16px 12px 4px 22px; }
  h2 { margin: 0; font-size: 20px; font-weight: 300; letter-spacing: .01em; }
  .body { overflow-y: auto; padding: 8px 22px 26px; -webkit-overflow-scrolling: touch; }
  .sub { margin: 0 0 14px; color: var(--haze); font-size: 13px; line-height: 1.5; }
  h3 { margin: 22px 0 8px; font-size: 13px; font-weight: 600; color: var(--haze); }
  @media (prefers-reduced-motion: reduce) { .scrim, .panel { transition: none; } }
`;
