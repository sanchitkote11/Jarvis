export class Analyser {
  private analyser: AnalyserNode;
  private dataArray: Uint8Array<ArrayBuffer>;

  constructor(node: AudioNode) {
    this.analyser = node.context.createAnalyser();
    this.analyser.fftSize = 32; // 16 frequency bins
    this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    node.connect(this.analyser);
  }
  update() { this.analyser.getByteFrequencyData(this.dataArray); }
  get data(): Uint8Array { return this.dataArray; }
  dispose() { try { this.analyser.disconnect(); } catch { /* ignore */ } }
}
