import { storage } from './storage';
import { uid } from './utils';

export type MemoryCategory = 'like' | 'dislike' | 'preference' | 'fact' | 'person' | 'goal' | 'other';
export type MemorySource = 'voice' | 'auto' | 'manual';
export interface MemoryItem {
  id: string; text: string; category: MemoryCategory; importance: 1 | 2 | 3;
  createdAt: number; updatedAt: number; source: MemorySource;
}
export const CATEGORIES: ReadonlyArray<{ id: MemoryCategory; label: string; prompt: string }> = [
  { id: 'like', label: 'Things you like', prompt: 'Likes' },
  { id: 'dislike', label: 'Things you dislike', prompt: 'Dislikes' },
  { id: 'preference', label: 'How you like things done', prompt: 'Preferences' },
  { id: 'fact', label: 'About you', prompt: 'About them' },
  { id: 'person', label: 'People in your life', prompt: 'People' },
  { id: 'goal', label: 'Goals and projects', prompt: 'Goals and projects' },
  { id: 'other', label: 'Other notes', prompt: 'Other' },
];
export const asCategory = (v: unknown): MemoryCategory =>
  CATEGORIES.some((c) => c.id === v) ? (v as MemoryCategory) : 'other';

const STOP = new Set('a an the is are was were be to of and or in on at for with user they he she it that this their his her my your i me we you as by from has have had does do like likes'.split(' '));
const normalize = (s: string) => s.toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();
const tokens = (s: string) => normalize(s).split(' ').filter((w) => w.length > 1 && !STOP.has(w));

export function similarity(a: string, b: string): number {
  if (normalize(a) === normalize(b)) return 1;
  const A = new Set(tokens(a)), B = new Set(tokens(b));
  if (!A.size || !B.size) return 0;
  let inter = 0; for (const t of A) if (B.has(t)) inter++;
  const jaccard = inter / (A.size + B.size - inter);
  const small = Math.min(A.size, B.size);
  const contain = small >= 3 ? (inter / small) * 0.9 : 0;
  return Math.max(jaccard, contain);
}

const SENSITIVE = [
  /\b(?:\d[ -]?){13,19}\b/, /pass(?:word|code)|\bpin\b|\bcvv\b|\bssn\b|social security/i,
  /AIza[0-9A-Za-z_-]{20,}/, /\bsk-[A-Za-z0-9]{16,}/, /api[ _-]?key|secret key|private key/i,
];
export const looksSensitive = (t: string) => SENSITIVE.some((r) => r.test(t));

export type AddResult =
  | { status: 'added' | 'duplicate' | 'replaced'; item: MemoryItem }
  | { status: 'rejected'; reason: string };

const KEY = 'jarvis.memory.v1';
const MAX_ITEMS = 500;

export class MemoryStore extends EventTarget {
  private items: MemoryItem[] = storage.getJSON<MemoryItem[]>(KEY, []);

  private save() { storage.setJSON(KEY, this.items); this.dispatchEvent(new Event('change')); }
  get count() { return this.items.length; }
  list(): MemoryItem[] { return [...this.items].sort((a, b) => b.importance - a.importance || b.updatedAt - a.updatedAt); }

  add(raw: string, category: MemoryCategory = 'other',
      opts: { importance?: 1 | 2 | 3; replaces?: string; source?: MemorySource } = {}): AddResult {
    const text = raw.replace(/\s+/g, ' ').trim().slice(0, 280);
    if (text.length < 3) return { status: 'rejected', reason: 'That is too short to save.' };
    if (looksSensitive(text)) return { status: 'rejected', reason: 'I do not store passwords, card numbers or other secrets.' };
    const now = Date.now();
    const importance = opts.importance ?? 2;
    const dup = this.items.find((m) => similarity(m.text, text) >= 0.8);
    if (dup) {
      dup.updatedAt = now; dup.importance = Math.max(dup.importance, importance) as 1 | 2 | 3;
      this.save(); return { status: 'duplicate', item: dup };
    }
    let status: 'added' | 'replaced' = 'added';
    if (opts.replaces) {
      const old = this.best(opts.replaces, 0.4);
      if (old) { this.items = this.items.filter((m) => m.id !== old.id); status = 'replaced'; }
    }
    const item: MemoryItem = { id: uid(), text, category, importance, createdAt: now, updatedAt: now, source: opts.source ?? 'voice' };
    this.items.push(item);
    if (this.items.length > MAX_ITEMS) {
      this.items.sort((a, b) => a.importance - b.importance || a.updatedAt - b.updatedAt);
      this.items.splice(0, this.items.length - MAX_ITEMS);
    }
    this.save(); return { status, item };
  }

  private score(m: MemoryItem, query: string): number {
    const q = normalize(query);
    if (!q) return 0;
    const qt = tokens(query);
    const mt = new Set(tokens(m.text));
    const overlap = qt.length ? qt.filter((t) => mt.has(t)).length / qt.length : 0;
    return Math.max(overlap, normalize(m.text).includes(q) ? 1 : 0);
  }
  private best(query: string, min: number): MemoryItem | null {
    let top: MemoryItem | null = null, s = min;
    for (const m of this.items) { const v = this.score(m, query); if (v >= s) { s = v; top = m; } }
    return top;
  }
  search(query: string, limit = 12): MemoryItem[] {
    if (!query.trim()) return this.list().slice(0, limit);
    return this.items.map((m) => ({ m, s: this.score(m, query) })).filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s || b.m.importance - a.m.importance).slice(0, limit).map((x) => x.m);
  }
  matching(query: string): MemoryItem[] { return this.items.filter((m) => this.score(m, query) >= 0.6); }
  removeIds(ids: string[]) { this.items = this.items.filter((m) => !ids.includes(m.id)); this.save(); }
  remove(id: string) { this.removeIds([id]); }
  clear() { this.items = []; this.save(); }

  exportJSON(): string { return JSON.stringify({ app: 'jarvis', version: 1, memories: this.items }, null, 2); }
  importJSON(json: string): { added: number; skipped: number } {
    let added = 0, skipped = 0;
    const data = JSON.parse(json) as { memories?: Array<Partial<MemoryItem>> } | Array<Partial<MemoryItem>>;
    const list = Array.isArray(data) ? data : data.memories ?? [];
    for (const m of list) {
      if (!m || typeof m.text !== 'string') { skipped++; continue; }
      const imp = ([1, 2, 3] as const).includes(m.importance as 1 | 2 | 3) ? (m.importance as 1 | 2 | 3) : 2;
      const r = this.add(m.text, asCategory(m.category), { importance: imp, source: 'manual' });
      if (r.status === 'added' || r.status === 'replaced') added++; else skipped++;
    }
    return { added, skipped };
  }
}

/** Compact text block injected into the system prompt. */
export function memoryPromptSection(items: MemoryItem[], maxChars = 3800): string {
  if (!items.length) return '(Nothing saved yet.)';
  const lines: string[] = [];
  let used = 0, shown = 0;
  for (const cat of CATEGORIES) {
    const group = items.filter((m) => m.category === cat.id);
    if (!group.length) continue;
    const kept: string[] = [];
    for (const m of group) {
      const line = `- ${m.text}`;
      if (used + line.length > maxChars) break;
      kept.push(line); used += line.length + 1; shown++;
    }
    if (kept.length) lines.push(`${cat.prompt}:`, ...kept);
  }
  if (shown < items.length) lines.push(`(${items.length - shown} more saved; use recall_memories to look them up.)`);
  return lines.join('\n');
}

export interface LogEntry { id: string; role: 'user' | 'model'; text: string; ts: number }
const LOG_KEY = 'jarvis.log.v1';
export class ConversationLog extends EventTarget {
  private entries: LogEntry[] = storage.getJSON<LogEntry[]>(LOG_KEY, []);
  all() { return this.entries; }
  append(role: 'user' | 'model', text: string, ts = Date.now()) {
    this.entries.push({ id: uid(), role, text: text.slice(0, 800), ts });
    if (this.entries.length > 120) this.entries.splice(0, this.entries.length - 120);
    storage.setJSON(LOG_KEY, this.entries); this.dispatchEvent(new Event('change'));
  }
  clear() { this.entries = []; storage.remove(LOG_KEY); this.dispatchEvent(new Event('change')); }
  recap(n = 8, maxChars = 1400): string {
    const out: string[] = []; let used = 0;
    for (const e of this.entries.slice(-n).reverse()) {
      const line = `${e.role === 'user' ? 'User' : 'Jarvis'}: ${e.text.slice(0, 220)}`;
      if (used + line.length > maxChars) break;
      out.unshift(line); used += line.length;
    }
    return out.join('\n');
  }
}
