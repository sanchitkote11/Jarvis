import { LitElement, css, html, nothing } from 'lit';
import { ACCENTS, APP_NAME, APP_VERSION, LIVE_MODEL_PRESETS, VOICES } from './config';
import { iconClose } from './icons';
import type { Persona, Settings } from './settings';
import { baseStyles, sheetStyles } from './ui-styles';

const TOGGLES: Array<{ key: keyof Settings; label: string; hint: string }> = [
  { key: 'autoLearn', label: 'Learn from our conversations', hint: 'After each chat, Jarvis saves lasting likes and facts.' },
  { key: 'recallRecent', label: 'Remember recent chats', hint: 'Lets Jarvis pick up where you left off.' },
  { key: 'greet', label: 'Greet me when I start', hint: '' },
  { key: 'captions', label: 'Show captions', hint: '' },
  { key: 'googleSearch', label: 'Search Google for live info', hint: 'Weather, news, scores.' },
  { key: 'echoGuard', label: 'Mute my mic while Jarvis talks', hint: 'Turn on if Jarvis hears itself. You then cannot interrupt by voice.' },
  { key: 'haptics', label: 'Haptic feedback', hint: '' },
];

export class JarvisSettingsSheet extends LitElement {
  static properties = {
    open: { type: Boolean, reflect: true }, settings: { attribute: false }, keyHint: { type: String },
    keyDraft: { state: true }, customModel: { state: true },
  };
  declare open: boolean; declare settings: Settings; declare keyHint: string;
  declare keyDraft: string; declare customModel: boolean;

  static styles = [baseStyles, sheetStyles, css`
    label.field { display: block; margin-bottom: 10px; }
    label.field > span { display: block; font-size: 13px; margin-bottom: 6px; }
    .seg { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
    .seg button { height: 42px; border-radius: 12px; border: 1px solid var(--line); font-size: 13px; }
    .seg button[aria-pressed=true] { border-color: var(--accent); background: color-mix(in srgb, var(--accent) 22%, transparent); }
    .swatches { display: grid; grid-template-columns: repeat(8, 1fr); gap: 8px; }
    .swatches button { aspect-ratio: 1; border-radius: 50%; border: 2px solid transparent; }
    .swatches button[aria-pressed=true] { border-color: var(--ink); }
    .tg { display: flex; align-items: center; gap: 14px; padding: 11px 0; border-bottom: 1px solid var(--line); }
    .tg .l { flex: 1; font-size: 14px; } .tg small { display: block; margin-top: 2px; }
    .tg input { appearance: none; -webkit-appearance: none; width: 46px; height: 28px; border-radius: 999px; background: rgba(255,255,255,.14); position: relative; flex: none; transition: background .2s; }
    .tg input::after { content: ''; position: absolute; top: 3px; left: 3px; width: 22px; height: 22px; border-radius: 50%; background: var(--ink); transition: transform .2s; }
    .tg input:checked { background: var(--accent); } .tg input:checked::after { transform: translateX(18px); background: #04060f; }
    .keyrow { display: grid; grid-template-columns: 1fr auto; gap: 8px; }
    details { margin-top: 18px; } summary { font-size: 13px; color: var(--haze); cursor: pointer; padding: 6px 0; }
    .ver { margin-top: 22px; text-align: center; }
    @media (prefers-reduced-motion: reduce) { .tg input, .tg input::after { transition: none; } }
  `];

  constructor() { super(); this.open = false; this.keyHint = ''; this.keyDraft = ''; this.customModel = false; this.settings = undefined as unknown as Settings; }
  private close() { this.dispatchEvent(new CustomEvent('close', { bubbles: true, composed: true })); }
  private set(patch: Partial<Settings>) { this.dispatchEvent(new CustomEvent('settings-change', { detail: patch, bubbles: true, composed: true })); }
  private saveKey() { this.dispatchEvent(new CustomEvent('save-key', { detail: this.keyDraft, bubbles: true, composed: true })); this.keyDraft = ''; }

  render() {
    const s = this.settings; if (!s) return nothing;
    const preset = LIVE_MODEL_PRESETS.some((p) => p.id === s.liveModel);
    const personas: Array<[Persona, string]> = [['jarvis', 'Jarvis'], ['friendly', 'Friendly'], ['concise', 'Brief']];
    return html`<div class="scrim" @click=${this.close}></div>
      <section class="panel" role="dialog" aria-label="Settings" ?inert=${!this.open}>
        <header><h2>Settings</h2><button class="icon-btn" aria-label="Close" @click=${this.close}>${iconClose}</button></header>
        <div class="body">
          <h3>You</h3>
          <label class="field"><span>What should Jarvis call you?</span>
            <input type="text" .value=${s.userName} maxlength="40" @change=${(e: Event) => this.set({ userName: (e.target as HTMLInputElement).value.trim() })} /></label>
          <label class="field"><span>Voice</span>
            <select @change=${(e: Event) => this.set({ voice: (e.target as HTMLSelectElement).value })}>
              ${VOICES.map((v) => html`<option value=${v.name} ?selected=${v.name === s.voice}>${v.name}, ${v.tone.toLowerCase()}</option>`)}</select></label>
          <div class="field"><span style="font-size:13px;display:block;margin-bottom:6px">Personality</span>
            <div class="seg">${personas.map(([id, label]) => html`<button aria-pressed=${s.persona === id} @click=${() => this.set({ persona: id })}>${label}</button>`)}</div></div>
          <h3>Orb color</h3>
          <div class="swatches">${ACCENTS.map((a) => html`<button aria-label=${a.name} aria-pressed=${s.accent === a.value}
            style="background:${a.value}" @click=${() => this.set({ accent: a.value })}></button>`)}</div>
          <h3>Behavior</h3>
          ${TOGGLES.map((t) => html`<label class="tg"><span class="l">${t.label}${t.hint ? html`<small>${t.hint}</small>` : nothing}</span>
            <input type="checkbox" role="switch" .checked=${s[t.key] as boolean} @change=${(e: Event) => this.set({ [t.key]: (e.target as HTMLInputElement).checked } as Partial<Settings>)} /></label>`)}
          <h3>Gemini API key</h3>
          <p class="sub">${this.keyHint || 'No key yet. Create one for free in Google AI Studio, then paste it here.'}</p>
          <div class="keyrow"><input type="password" placeholder="Paste a new key" autocomplete="off" .value=${this.keyDraft}
            @input=${(e: Event) => (this.keyDraft = (e.target as HTMLInputElement).value)} />
            <button class="pill primary" ?disabled=${!this.keyDraft.trim()} @click=${this.saveKey}>Save key</button></div>
          <details><summary>Advanced</summary>
            <label class="field"><span>Live model</span>
              <select @change=${(e: Event) => { const v = (e.target as HTMLSelectElement).value; if (v === '__custom') this.customModel = true; else { this.customModel = false; this.set({ liveModel: v }); } }}>
                ${LIVE_MODEL_PRESETS.map((p) => html`<option value=${p.id} ?selected=${p.id === s.liveModel}>${p.label}</option>`)}
                <option value="__custom" ?selected=${!preset || this.customModel}>Other model ID</option></select></label>
            ${!preset || this.customModel ? html`<label class="field"><span>Model ID</span><input type="text" .value=${s.liveModel}
              @change=${(e: Event) => this.set({ liveModel: (e.target as HTMLInputElement).value.trim() || 'gemini-3.8-live' })} /></label>` : nothing}
            <label class="field"><span>Model used for learning</span><input type="text" .value=${s.textModel}
              @change=${(e: Event) => this.set({ textModel: (e.target as HTMLInputElement).value.trim() || 'gemini-3.8-flash' })} /></label>
          </details>
          <p class="muted ver">${APP_NAME} ${APP_VERSION}</p>
        </div>
      </section>`;
  }
}
customElements.define('jarvis-settings-sheet', JarvisSettingsSheet);
