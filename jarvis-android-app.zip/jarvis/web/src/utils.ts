export function encodeBase64(bytes: Uint8Array): string {
  let binary = '';
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + step) as unknown as number[]);
  }
  return btoa(binary);
}

export function decodeBase64(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/** Float32 (-1..1) to 16-bit linear PCM (-32768..32767). */
export function floatToInt16(input: Float32Array): Int16Array {
  const out = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    out[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return out;
}

export function createPcmBlob(f32: Float32Array): { data: string; mimeType: string } {
  const pcm = floatToInt16(f32);
  return { data: encodeBase64(new Uint8Array(pcm.buffer)), mimeType: 'audio/pcm;rate=16000' };
}

/** Synchronous so playback scheduling stays atomic. */
export function pcm16ToAudioBuffer(bytes: Uint8Array, ctx: BaseAudioContext, sampleRate: number): AudioBuffer {
  const count = Math.floor(bytes.byteLength / 2);
  const buffer = ctx.createBuffer(1, Math.max(count, 1), sampleRate);
  const ch = buffer.getChannelData(0);
  const view = new DataView(bytes.buffer, bytes.byteOffset, count * 2);
  for (let i = 0; i < count; i++) ch[i] = view.getInt16(i * 2, true) / 32768;
  return buffer;
}

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export function uid(): string {
  return globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function timeAgo(ts: number): string {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  if (s < 86400 * 30) return `${Math.floor(s / 86400)} d ago`;
  return new Date(ts).toLocaleDateString();
}

export function withTimeout<T>(p: Promise<T>, ms: number, label = 'timeout'): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(label)), ms);
    p.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
  });
}
