package com.jarvis.live

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

private const val APP_HOST = "appassets.androidplatform.net"
private const val APP_URL = "https://$APP_HOST/assets/dist/index.html"

class AudioOrbActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var permissionView: View
    private lateinit var bridge: WebAppInterface
    private var appLoaded = false

    // Serves /assets/ from the APK over https so ES modules, fetch() and Web Audio all work.
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(APP_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) showWebApp() else showPermissionNeeded()
        }

    // Enabled only while the web UI has a sheet open (see AndroidBridge.setBackHandled).
    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            webView.evaluateJavascript("window.__jarvisBack && window.__jarvisBack()", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        bridge = WebAppInterface(this)
        buildViews()
        onBackPressedDispatcher.addCallback(this, backCallback)
        // Request the microphone BEFORE loading the WebView.
        if (hasMic()) showWebApp() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    override fun onResume() {
        super.onResume()
        if (!appLoaded && hasMic()) showWebApp() // returned from system settings
        if (appLoaded) webView.onResume()
    }

    override fun onPause() {
        if (appLoaded) webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (appLoaded) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy() }
        super.onDestroy()
    }

    fun setBackHandled(handled: Boolean) { backCallback.isEnabled = handled }
    fun openExternal(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { /* no handler */ }
    }
    fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildViews() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        webView = WebView(this).apply { visibility = View.GONE }
        permissionView = buildPermissionView()
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(webView, FrameLayout.LayoutParams(match, match))
        root.addView(permissionView, FrameLayout.LayoutParams(match, match))
        setContentView(root)
    }

    private fun buildPermissionView(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            visibility = View.GONE
        }
        col.addView(TextView(this).apply {
            text = getString(R.string.mic_needed_title); setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = getString(R.string.mic_needed_body); setTextColor(0xFFB4BCE0.toInt()); textSize = 15f
            gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(24))
        })
        col.addView(Button(this).apply {
            text = getString(R.string.mic_needed_button)
            setOnClickListener {
                if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                } else {
                    openAppSettings() // permanently denied: only system settings can fix it
                }
            }
        })
        return col
    }

    private fun showPermissionNeeded() {
        webView.visibility = View.GONE
        permissionView.visibility = View.VISIBLE
    }

    private fun showWebApp() {
        permissionView.visibility = View.GONE
        webView.visibility = View.VISIBLE
        if (!appLoaded) {
            configureWebView()
            webView.loadUrl(APP_URL)
            appLoaded = true
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false // lets Web Audio speak without a tap
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            textZoom = 100
            userAgentString = "$userAgentString JarvisApp/${BuildConfig.VERSION_NAME}"
        }
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.setBackgroundColor(Color.BLACK)
        webView.setOnLongClickListener { true }
        webView.isLongClickable = false
        webView.addJavascriptInterface(bridge, "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            // The bridge exposes the API key, so never let the WebView navigate away from our own origin.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == APP_HOST) return false
                openExternal(request.url)
                return true
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                recreate()
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val trusted = request.origin.host == APP_HOST
                    val wantsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (trusted && wantsMic && hasMic()) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    } else {
                        request.deny()
                    }
                }
            }

            override fun onConsoleMessage(msg: ConsoleMessage): Boolean {
                if (BuildConfig.DEBUG) Log.d("JarvisWeb", "${msg.message()} (${msg.sourceId()}:${msg.lineNumber()})")
                return true
            }
        }
    }
}
