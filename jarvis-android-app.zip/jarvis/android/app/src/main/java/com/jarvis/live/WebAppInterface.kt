package com.jarvis.live

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.AlarmClock
import android.view.WindowManager
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Exposed to the web app as window.AndroidBridge. Only primitives cross the bridge. */
class WebAppInterface(private val activity: AudioOrbActivity) {

    private val kv = activity.getSharedPreferences("jarvis_kv", Context.MODE_PRIVATE)       // backed up
    private val secrets = activity.getSharedPreferences("jarvis_secrets", Context.MODE_PRIVATE) // never backed up

    /* ---- key and storage ---- */
    @JavascriptInterface fun getApiKey(): String {
        val saved = secrets.getString("api_key", "") ?: ""
        return if (saved.isNotBlank()) saved else BuildConfig.GEMINI_API_KEY
    }
    @JavascriptInterface fun setApiKey(key: String) { secrets.edit().putString("api_key", key.trim()).apply() }
    @JavascriptInterface fun kvGet(key: String): String? = kv.getString(key, null)
    @JavascriptInterface fun kvSet(key: String, value: String) { kv.edit().putString(key, value).apply() }
    @JavascriptInterface fun kvRemove(key: String) { kv.edit().remove(key).apply() }

    /* ---- window ---- */
    @JavascriptInterface fun setKeepScreenOn(on: Boolean) {
        activity.runOnUiThread {
            val flag = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            if (on) activity.window.addFlags(flag) else activity.window.clearFlags(flag)
        }
    }
    @JavascriptInterface fun setBackHandled(on: Boolean) { activity.runOnUiThread { activity.setBackHandled(on) } }
    @JavascriptInterface fun openAppSettings() { activity.runOnUiThread { activity.openAppSettings() } }

    @Suppress("DEPRECATION")
    @JavascriptInterface fun vibrate(ms: Int) {
        val v = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createOneShot(ms.toLong().coerceIn(1, 500), VibrationEffect.DEFAULT_AMPLITUDE))
    }

    /* ---- device info and actions ---- */
    @JavascriptInterface fun getBatteryInfo(): String {
        val i = activity.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return JSONObject().put("level", if (level >= 0) level * 100 / scale else -1).put("charging", charging).toString()
    }

    @JavascriptInterface fun getDeviceInfo(): String =
        JSONObject().put("model", Build.MODEL).put("android", Build.VERSION.RELEASE).put("app", BuildConfig.VERSION_NAME).toString()

    @JavascriptInterface fun setTimer(seconds: Int, label: String): Boolean = start(
        Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceIn(1, 86400))
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )

    @JavascriptInterface fun setAlarm(hour: Int, minute: Int, label: String): Boolean = start(
        Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
    )

    @JavascriptInterface fun openUrl(url: String): Boolean {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" && uri.scheme != "http") return false
        return start(Intent(Intent.ACTION_VIEW, uri))
    }

    @JavascriptInterface fun openMaps(query: String): Boolean {
        val geo = start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query))))
        return geo || start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))))
    }

    @JavascriptInterface fun shareText(text: String): Boolean = start(
        Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null)
    )

    @JavascriptInterface fun setTorch(on: Boolean): Boolean = onMain(false) {
        try {
            val cm = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return@onMain false
            cm.setTorchMode(id, on); true
        } catch (_: Exception) { false }
    }

    /* ---- helpers ---- */
    private fun start(intent: Intent): Boolean = onMain(false) {
        try { activity.startActivity(intent); true } catch (_: Exception) { false }
    }

    /** JS bridge calls arrive on a background thread; run UI work on the main thread and wait briefly. */
    private fun <T> onMain(default: T, block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val latch = CountDownLatch(1)
        var result = default
        activity.runOnUiThread { try { result = block() } finally { latch.countDown() } }
        latch.await(2, TimeUnit.SECONDS)
        return result
    }
}
