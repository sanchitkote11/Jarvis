# Jarvis

A voice assistant with a living 3D orb, built on the Gemini Live API. It remembers what you like, learns from your chats, and runs as a web app or an Android app (WebView).

## Get the APK (no computer needed)
1. Create a GitHub repo and upload this whole folder.
2. Optional: Settings > Secrets > Actions > add `GEMINI_API_KEY`. Skip it and paste your key inside the app instead.
3. Open the Actions tab, run "Build Jarvis APK", download the `jarvis-debug-apk` artifact, install it.

## Build with Android Studio
```
cd web && npm install && npm run build   # writes into android/app/src/main/assets/dist
```
Open `android/` in Android Studio and run. Put `GEMINI_API_KEY=...` in `android/local.properties` to bake a key in (optional).

## Run in a browser
`cd web && npm install`, put `GEMINI_API_KEY=...` in `web/.env`, then `npm run dev`. The mic needs https or localhost.

## Memory
- Say things like "I love jazz" or "remember my sister's birthday is June 3". Jarvis saves it with a tool call.
- After each chat, a background pass saves lasting likes and facts (toggle: Learn from our conversations).
- Open the heart icon to search, add, delete, export or import memories. "Forget that" works by voice too.
- Memory lives in the app's storage and is included in Android backup. The API key is not.
- Passwords and card numbers are never saved.

## Also included
Live captions, conversation log, 30 voices, personalities, orb color (say "make the orb orange"), Google Search, timers, alarms, battery, flashlight, maps, share sheet, auto-reconnect with session resumption, adaptive render quality.

## Notes
- Models: `gemini-3.8-live` for voice, `gemini-3.8-flash` for learning. If connecting fails with "model not found", change it in Settings > Advanced.
- Optional look: drop `piz_compressed.exr` into `web/src/assets/` to use it as the reflection map. Otherwise a built-in studio environment is used.
- The key is readable by the WebView. For anything you distribute, mint short-lived Gemini ephemeral tokens from a server.
- Audio capture uses an AudioWorklet (20 ms chunks) and falls back to `ScriptProcessorNode(256)`. Sessions end when the app goes to the background.
- Not compiled or run in the environment this was written in. If the first build errors, send me the message.
